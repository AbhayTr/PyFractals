from pyfractals.pyfractals import MandelBrot
